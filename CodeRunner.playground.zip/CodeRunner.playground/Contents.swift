 import SpriteKit
 import PlaygroundSupport
 import GameplayKit
//Set Size of Window
let width = 500
let height = 500

//Create Start Scene
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: width, height: height))
if let scene = StartScene(fileNamed: "StartScene") {
    scene.scaleMode = .aspectFit
    sceneView.presentScene(scene)
}
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

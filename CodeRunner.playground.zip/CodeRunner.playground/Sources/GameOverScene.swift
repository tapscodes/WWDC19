//
//  GameOverScene.swift
//  CodeRunner
//
//  Created by Tristan Pudell on 3/16/18.
//  Copyright © 2019 Tristan Pudell. All rights reserved.
//
import SpriteKit
import GameplayKit
import Cocoa
//title || start screen
public class GameOverScene: SKScene {
    var endS: SKLabelNode!
    var endHS: SKLabelNode!
    var hs: Int!
    public override func sceneDidLoad() {
        //sets up score label node
        guard let endS = childNode(withName: "endScore") as? SKLabelNode else {
            fatalError("NO endS LOADED")
        }
        self.endS = endS
        //sets up high score label
        guard let endHS = childNode(withName: "endHighscore") as? SKLabelNode else {
            fatalError("NO endHS LOADED")
        }
        self.endHS = endHS
        run(SKAction.repeatForever(SKAction.playSoundFileNamed("error.mp3", waitForCompletion: true)))
    }
    func setScore(score: Int, highScore: Int){
        self.hs=highScore
        endS.text = "Lines Written: "+String(score)
        endHS.text = "Most Lines Written: "+String(highScore)
    }
    //resets game when clicked
    override public func mouseUp(with theEvent: NSEvent) {
        if let scene = GameScene(fileNamed: "GameScene") {
            scene.scaleMode = .aspectFit
            scene.highScore=self.hs
            scene.highscoreLabel.text = String(self.hs)
            self.scene?.view?.presentScene(scene, transition: SKTransition.crossFade(withDuration: 0.3))
        }
    }
}

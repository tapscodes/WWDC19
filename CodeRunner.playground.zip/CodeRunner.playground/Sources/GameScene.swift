//
//  GameScene.swift
//  CodeRunner
//
//  Created by Tristan Pudell on 3/16/18.
//  Copyright © 2019 Tristan Pudell. All rights reserved.
//
import SpriteKit
import GameplayKit
import Cocoa
//the game code
public class GameScene: SKScene, SKPhysicsContactDelegate {
    //MARK: -Nodes
    var player: SKSpriteNode!
    var scoreLabel: SKLabelNode!
    var highscoreLabel: SKLabelNode!
    //MARK: -Structs
    struct Collisions {
        static let None: UInt32 = 0
        static let All: UInt32 = UInt32.max
        static let Player: UInt32 = UInt32(1)
        static let Platform: UInt32 = UInt32(2)
        static let Border: UInt32 = UInt32(4)
        static let Obstacle: UInt32 = UInt32(8)
        static let RightBorder: UInt32 = UInt32(16)
    }
    //MARK: -Arrays
    var obstacles = ["error", "warning","oldError","bomb"]
    //MARK: -Game Vars
    var alive = true
    var grounded = true
    var score = 0
    var highScore = 0
    var x = 0
    //MARK: -Time Vars
    var lastTime: TimeInterval = 0
    var currentTime: TimeInterval = 0.0
    var nextPlaftormTime = 2.0
    var lastPlatformTime = 0.0
    var nextScoreTime = 0.4
    var lastScoreTime = 0.0
    //MARK: -Main Setup
    override public func sceneDidLoad() {
        //resets just the score(not highscore)
        score=0
        //loads player node
        guard let player = childNode(withName: "player") as? SKSpriteNode else {
            fatalError("NO PLAYER LOADED")
        }
        player.zPosition = 5
        self.player = player
        //sets up score label node
        guard let scoreLabel = childNode(withName: "scoreLabel") as? SKLabelNode else {
            fatalError("NO SCORE LOADED")
        }
        self.scoreLabel = scoreLabel
        //sets up high score label
        guard let highscoreLabel = childNode(withName: "highscoreLabel") as? SKLabelNode else {
            fatalError("NO HIGH SCORE LOADED")
        }
        self.highscoreLabel = highscoreLabel
        //sets up right border(to keep player on left)
        guard let rightBarrier = childNode(withName: "rightBarrier")
            as? SKSpriteNode else {
                fatalError("NO RIGHT BARRIER LOADED")
        }
        //sets up barrier on the right in order to keep player on left side of screen
        rightBarrier.physicsBody = SKPhysicsBody(rectangleOf: rightBarrier.size)
        rightBarrier.physicsBody?.isDynamic = false
        rightBarrier.physicsBody?.categoryBitMask = Collisions.RightBorder
        rightBarrier.physicsBody?.contactTestBitMask = Collisions.Player
        //sets up edges of program
        let border = SKPhysicsBody(edgeLoopFrom: self.frame)
        border.friction = 0
        self.physicsBody = border
        //sets up physics for player and then starts game
        setup(sprite: player)
        player.physicsBody?.categoryBitMask = Collisions.Player
        player.physicsBody?.collisionBitMask = Collisions.Border | Collisions.Platform | Collisions.Obstacle
        border.categoryBitMask = Collisions.Border
        border.contactTestBitMask = Collisions.Player
        physicsWorld.contactDelegate = self
    }
    //MARK: -Physics Setup
    //sets up basic sprite physics for any normal sprite
    func setup(sprite: SKSpriteNode!){
    sprite.physicsBody = SKPhysicsBody(rectangleOf: sprite.size)
    sprite.position = CGPoint(x:-600,y:0)
    sprite.physicsBody?.affectedByGravity = true
    sprite.physicsBody?.isDynamic = true
    sprite.physicsBody?.allowsRotation = false
    sprite.physicsBody?.restitution = 0
    sprite.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
    }
    //what happens when there is contact
    public func didBegin(_ contact: SKPhysicsContact) {
        //sorts Collision
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        switch firstBody.categoryBitMask {
        case Collisions.Player:
            switch secondBody.categoryBitMask {
            case Collisions.Obstacle:
                alive=false
                gameOver()
            case Collisions.Platform:
                grounded=true
            case Collisions.Border:
                grounded=true
            default:
              break
            }
        default:
          break
        }
    }
    //when collision ends
    public func didEnd(_ contact: SKPhysicsContact) {
        //sorts Collision
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        switch firstBody.categoryBitMask {
        case Collisions.Player:
            switch secondBody.categoryBitMask {
            case Collisions.Border:
                grounded=false
            case Collisions.Platform:
                grounded=false
            default:
                break
            }
        default:
            break
        }    }
    //MARK: -Score
    //increases score by 1
    func scoreUp(){
        score+=1
        if(score>highScore){
            highScore = score
            highscoreLabel.text = String(score)
        }
        scoreLabel.text = String(score)
    }
    //MARK: -Object Spawning
    //keeps spawning platforms
    func spawnPlatform(y: Int){
        //PLATFORM
        //sets platform image+size
        let platform = SKSpriteNode(imageNamed: "platform")
        platform.size = CGSize(width: 300, height: 40)
        //sets position to the given y
        platform.position = CGPoint(x: 1500, y: y)
        platform.zPosition = 3
        //sets up platform phsyics
        platform.physicsBody = SKPhysicsBody(edgeFrom: CGPoint(x: -platform.size.width/2, y: (platform.size.height/2)), to: CGPoint(x: platform.size.width/2, y: (platform.size.height/2)))
        platform.physicsBody?.isDynamic = false
        platform.physicsBody?.restitution = 0
        //add platform collsions
        platform.physicsBody?.categoryBitMask = Collisions.Platform
        platform.physicsBody?.contactTestBitMask = Collisions.Player
        //adds platform to scene
        addChild(platform)
        //OBSTACLE
        //sets obstacle to random obstacle from array
        let chosen = Int(random(min: 0, max: CGFloat(obstacles.count)))
        let obstacle = SKSpriteNode(imageNamed: obstacles[chosen])
        obstacle.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 25, height: 25))
        obstacle.size = CGSize(width: 50, height: 50)
        //places obstacle at random x relative to the platform
        let randomX = random(min: platform.frame.minX, max: platform.frame.maxX)
        //picks 1 or 2 for the if statement later
        let obsPos = Int(random(min:0, max:7))
        var yPos = CGFloat(y)
        //sets up phsyics
        obstacle.physicsBody?.restitution = 0
        //sets up obstacles y position(relative to platform+the random#)
        if(obsPos>4){
        yPos=CGFloat(y+350)
        obstacle.position = CGPoint(x: randomX, y: yPos)
        }
        else if(obsPos>2){
        yPos=CGFloat(y-150)
        obstacle.position = CGPoint(x: randomX, y: yPos)
        }
        else{
        yPos=CGFloat(y+40)
        obstacle.position = CGPoint(x: randomX, y: yPos)
        }
        obstacle.zPosition = 4
        obstacle.physicsBody?.isDynamic = false
        obstacle.physicsBody?.categoryBitMask = Collisions.Obstacle
        obstacle.physicsBody?.contactTestBitMask = Collisions.Player
        obstacle.physicsBody?.collisionBitMask = Collisions.None
        //adds obstacle to scene
        addChild(obstacle)
        //moves platform +obstacle left
        let actionMove2 = SKAction.move(to: CGPoint(x: -randomX, y: yPos), duration: 10)
        let actionMove = SKAction.move(to: CGPoint(x: -1500, y: y), duration: 10)
        //removes platform + obstacle when they are off screen
        let actionMoveDone2 = SKAction.removeFromParent()
        obstacle.run(SKAction.sequence([actionMove2, actionMoveDone2]))
        let actionMoveDone = SKAction.removeFromParent()
        platform.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    //MARK: -Random
    //returns random between max+min
    func random(min: CGFloat, max: CGFloat) -> CGFloat {
        return (CGFloat(Float(arc4random()) / 0xFFFFFFFF)) * (max - min) + min
    }
    //MARK: -Movement
    //when someone lets go of screen
    public override func mouseUp(with event: NSEvent) {
        player.physicsBody?.velocity.dy = 0
    }
    //when someone taps screen
    public override func mouseDown(with event: NSEvent) {
        if(alive && grounded){
            player.physicsBody?.velocity.dy = 1000
        }
    }
    //MARK - Time Related
    public override func update(_ currentTime: TimeInterval) {
        //Keep track of time between frames
        var timeElapsed: TimeInterval = 0
        if lastTime == 0 {
            timeElapsed = 0
        }
        else {
            timeElapsed = currentTime - lastTime
        }
        lastTime = currentTime
        self.currentTime = currentTime
        //makes player size correct
        player.size = CGSize(width: 150, height: 250)
        //spawns platform at next platform time interval
        if (currentTime - lastPlatformTime) >= nextPlaftormTime {
            //spawns platform at 5 different heights
            let ranY = Int(random(min: 0, max: 5))
            if(ranY == 0){
             spawnPlatform(y: -100)
            }
            else if(ranY == 1){
             spawnPlatform(y: -200)
            }
            else if(ranY == 2){
             spawnPlatform(y: 100)
            }
            else if (ranY==3){
             spawnPlatform(y: -300)
            }
            else{
             spawnPlatform(y: 0)
            }
            lastPlatformTime = currentTime
        }
        //increases score every second
        if (currentTime - lastScoreTime) >= nextScoreTime {
          scoreUp()
          lastScoreTime=currentTime
        }
        //disables window collisions while jumping
        if (player.physicsBody!.velocity.dy > CGFloat(0)){
         player.physicsBody?.collisionBitMask = Collisions.Border | Collisions.Obstacle
        }
        else{
         player.physicsBody?.collisionBitMask = Collisions.Border | Collisions.Platform | Collisions.Obstacle
        }
        scoreUp()
    }
    //MARK - Game Over
    //ends game
    func gameOver() {
        //freeze everything
        player.physicsBody?.isDynamic = false
        player.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
        //presents game over
        if let scene = GameOverScene(fileNamed: "GameOverScene") {
            scene.scaleMode = .aspectFit
            scene.setScore(score: self.score, highScore: self.highScore)
            self.scene?.view?.presentScene(scene, transition: SKTransition.crossFade(withDuration: 0.3))
        }
    }
}

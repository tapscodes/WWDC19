//
//  StartScene.swift
//  CodeRunner
//
//  Created by Tristan Pudell on 3/16/18.
//  Copyright © 2019 Tristan Pudell. All rights reserved.
//
import SpriteKit
import GameplayKit
import Cocoa
//title || start screen
public class StartScene: SKScene {
    //starts+presents game when clicked
    override public func mouseUp(with theEvent: NSEvent) {
        if let scene = GameScene(fileNamed: "GameScene") {
            scene.scaleMode = .aspectFit
            self.scene?.view?.presentScene(scene, transition: SKTransition.crossFade(withDuration: 0.3))
        }
    }
}
